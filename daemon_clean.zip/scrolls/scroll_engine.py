from scrolls.scroll_event import ScrollEvent
from scrolls.scroll_condition import ScrollCondition
from scrolls.scroll_action import ScrollAction
from scrolls.trigger_manager import check_scroll_triggers

class ScrollTrigger:
    def __init__(self, name, conditions, actions):
        self.name = name
        self.conditions = conditions  # List of ScrollCondition instances
        self.actions = actions        # List of ScrollAction instances

    def check_and_fire(self, event: ScrollEvent):
        if all(condition.evaluate(event) for condition in self.conditions):
            for action in self.actions:
                action.execute(event)
